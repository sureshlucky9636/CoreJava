package com.example.controller;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.example.entity.Plan;

import com.example.service.PlanServiceImpl;

@RestController
public class PlanController {
	
	@Autowired
	private PlanServiceImpl service;
	
	
	@PostMapping("/add")
	public Plan addplan(@RequestBody Plan  plan) {
		System.out.println(plan);
		return service.addplan(plan);
	}
	
	
	@GetMapping("/list")
	public List<Plan> viewall(){
		return service.viewallplan();
		
	}

	@DeleteMapping("/delete/{id}")
	public void delete(@PathVariable("id") int id) {
		service.deleteplan(id);
	}
	
	@GetMapping("/viewbyid/{id}")
	public Optional<Plan> viewbyid(@PathVariable("id") int id) {
		return service.viewbyid(id);
		
	}
	
	@PutMapping("/update")
	public Plan update(@RequestBody Plan plan) {
		return service.update(plan);
		
	}
}
