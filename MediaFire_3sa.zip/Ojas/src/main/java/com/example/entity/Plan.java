package com.example.entity;

import java.time.LocalDateTime;

import javax.persistence.Entity;
import javax.persistence.Id;

@Entity
public class Plan {

	@Id
	private int id;

	private String pName;

	private int nouser;

	private double price;

	private double storage;

	private String description;

	private LocalDateTime date;

	public Plan() {
		super();
	}

	public Plan(int id, String pName, int nouser, double price, double storage, String description,
			LocalDateTime date) {
		super();
		this.id = id;
		this.pName = pName;
		this.nouser = nouser;
		this.price = price;
		this.storage = storage;
		this.description = description;
		this.date = date;
	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getpName() {
		return pName;
	}

	public void setpName(String pName) {
		this.pName = pName;
	}

	public int getNouser() {
		return nouser;
	}

	public void setNouser(int nouser) {
		this.nouser = nouser;
	}

	public double getPrice() {
		return price;
	}

	public void setPrice(double price) {
		this.price = price;
	}

	public double getStorage() {
		return storage;
	}

	public void setStorage(double storage) {
		this.storage = storage;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	public LocalDateTime getDate() {
		return date;
	}

	public void setDate(LocalDateTime date) {
		this.date = date;
	}

	@Override
	public String toString() {
		return "Plan [id=" + id + ", pName=" + pName + ", nouser=" + nouser + ", price=" + price + ", storage="
				+ storage + ", description=" + description + ", date=" + date + "]";
	}

	
	
}
