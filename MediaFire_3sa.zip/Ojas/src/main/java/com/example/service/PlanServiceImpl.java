package com.example.service;

import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.entity.Plan;
import com.example.entity.PlanHistory;
import com.example.repository.PlanHistoryrepo;
import com.example.repository.Planrepo;

@Service
public class PlanServiceImpl implements PlanService {

	@Autowired
	private Planrepo repo;
	
	@Autowired
	private PlanHistoryrepo repository;

	@Override
	public Plan addplan(Plan plan) {	
		PlanHistory history = new PlanHistory();
		DateTimeFormatter dtf = DateTimeFormatter.ofPattern("yyyy/MM/dd HH:mm:ss");
		LocalDateTime now = LocalDateTime.now();
		plan.setDate(now);
		Plan temporaryPlan = repo.save(plan);
		BeanUtils.copyProperties(temporaryPlan, history);
		System.out.println(plan);
		repository.save(history);
		return repo.save(plan);
		
	}

	@Override
	public List<Plan> viewallplan() {
		List<Plan> viewlist = repo.findAll();
		return viewlist;
	}

	@Override
	public void deleteplan(int id) {
		repo.deleteById(id);

	}

	@Override
	public Optional<Plan> viewbyid(int id) {

		return repo.findById(id);
	}

	@Override
	public Plan update(Plan plan) {
		
		PlanHistory history = new PlanHistory();
		DateTimeFormatter dtf = DateTimeFormatter.ofPattern("yyyy/MM/dd HH:mm:ss");
		LocalDateTime now = LocalDateTime.now();
		plan.setDate(now);
		Plan temporaryPlan = repo.save(plan);
		BeanUtils.copyProperties(temporaryPlan, history);
		System.out.println(plan);
		repository.save(history);
		return repo.save(plan);
	}

}
