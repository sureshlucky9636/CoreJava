package com.example.service;

import java.util.List;
import java.util.Optional;

import com.example.entity.Plan;

public interface PlanService {
	
	
	public Plan addplan(Plan plan);
	
	public List<Plan> viewallplan();
	
	public void deleteplan(int id);
	
	public Optional<Plan> viewbyid(int id);
	
	public Plan update(Plan plan);
	
	

}
